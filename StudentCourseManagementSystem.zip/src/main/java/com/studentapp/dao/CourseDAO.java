package com.studentapp.dao;
import com.studentapp.model.Course;
import com.studentapp.util.DBConnection;
import java.sql.*;

public class CourseDAO {
    public void addCourse(Course course) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO courses (course_id, course_name) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, course.getCourseId());
            stmt.setString(2, course.getCourseName());
            stmt.executeUpdate();
            System.out.println("Course added successfully");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}