package com.studentapp.service;
import com.studentapp.dao.StudentDAO;
import com.studentapp.model.Student;

public class StudentService {
    StudentDAO dao = new StudentDAO();

    public void registerStudent(Student student) {
        dao.addStudent(student);
    }
}