package com.studentapp.service;
import com.studentapp.dao.CourseDAO;
import com.studentapp.model.Course;

public class CourseService {
    CourseDAO dao = new CourseDAO();

    public void addNewCourse(Course course) {
        dao.addCourse(course);
    }
}